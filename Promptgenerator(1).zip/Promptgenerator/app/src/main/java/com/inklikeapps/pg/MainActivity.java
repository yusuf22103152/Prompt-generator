package com.inklikeapps.pg;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int colorcount = 1;
    Button copy, generate, colcount, switchmode;
    String mode = "BASIC";
    EditText etcolors, etprompt;
    String[] colorlist = {"Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown", "Black", "White", "Gray", "Beige", "Turquoise", "Indigo", "Lavender", "Cyan", "Maroon", "Olive", "Gold", "Silver", "Teal", "Coral", "Mauve", "Salmon", "Tan", "Charcoal", "Plum", "Ivory", "Sky Blue", "Navy Blue", "Forest Green", "Lemon Yellow", "Peach", "Ruby", "Slate Gray", "Periwinkle", "Chocolate Brown", "Midnight Blue", "Rose", "Mint Green", "Mustard Yellow", "Lilac", "Sand", "Brick Red", "Orchid", "Seafoam Green", "Amber", "Cream", "Pewter", "Aqua", "Mahogany", "Slate Blue", "Tangerine", "Olive Green", "Cyan Blue", "Eggshell", "Coral Pink", "Burgundy", "Sage Green", "Dusty Rose", "Steel Blue", "Apricot", "Bronze", "Mint", "Ruby Red", "Champagne", "Cinnamon", "Fern Green", "Lavender Blue", "Sienna", "Tomato Red", "Topaz", "Vermilion", "Wheat", "Orchid Purple", "Royal Blue", "Olive Drab", "Coral Orange", "Pewter Gray", "Rust", "Aquamarine", "Lime", "Lemon", "Jade", "Tiffany Blue", "Electric Blue", "Hot Pink", "Magenta", "Terra Cotta", "Burnt Sienna", "Peacock Blue", "Emerald Green", "Royal Purple", "Sunset Orange", "Midnight Black", "Snow White", "Saffron Yellow", "Crimson Red", "Lapis Lazuli Blue", "Copper", "Platinum", "Amethyst Purple", "Chartreuse", "Moss Green", "Violet", "Sepia", "Azure Blue", "Ochre", "Goldenrod", "Linen White"};
    int[] colorlistPicked={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String colorListBasic[]={"Black", "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown", "White", "Gray", "Indigo", "Cyan", "Maroon", "Golden", "Silver", "Teal" };
    int[] colorListPickedBasic={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int min = 0;
    final int procolorcount = 110,basiccolorcount=17;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setContentView(R.layout.activity_main);

        copy=findViewById(R.id.bt_copy);
        switchmode=findViewById(R.id.bt_mode);
        etcolors=findViewById(R.id.et_colors);
        etprompt=findViewById(R.id.et_prompt);
        generate=findViewById(R.id.bt_generate);
        colcount=findViewById(R.id.bt_colcount);

        switchmode.setOnClickListener(view -> {
            if(mode.equals("BASIC")) mode="PRO";
            else mode="BASIC";
            switchmode.setText(mode);
        });
        copy.setOnClickListener(view -> {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

            // Create a new ClipData with the text
            String textToCopy=etcolors.getText().toString()+" "+etprompt.getText().toString();
            ClipData clipData = ClipData.newPlainText("", textToCopy);

            // Set the ClipData to the clipboard
            clipboardManager.setPrimaryClip(clipData);

            Toast.makeText(MainActivity.this, "Prompt copied to clipboard", Toast.LENGTH_SHORT).show();
        });
        colcount.setOnClickListener(view -> {
            colorcount++;
            if(colorcount>8) colorcount=1;
            colcount.setText(Integer.toString(colorcount));
        });

        generate.setOnClickListener(view -> {



            etcolors.setText("");
            String[] pickedcolors = new String[colorcount];
            for(int i=0;i<colorcount;i++) {

                if(mode.equals("PRO")) {
                    Random random = new Random();
                    int randomNumber;
                    do {
                        randomNumber = random.nextInt(procolorcount);
                    }
                    while (colorlistPicked[randomNumber] == 1);
                    colorlistPicked[randomNumber] = 1;
                    pickedcolors[i]=colorlist[randomNumber];
                }
                else {
                    Random random = new Random();
                    int randomNumber;
                    do {
                        randomNumber = random.nextInt(basiccolorcount);
                    }
                    while (colorListPickedBasic[randomNumber] == 1);
                    colorListPickedBasic[randomNumber] = 1;
                    pickedcolors[i]=colorListBasic[randomNumber];
                }

            }
            String tem="";
            for(int i=0;i<colorcount;i++) {
                tem+=pickedcolors[i];
                if(i==colorcount-1) continue;
                tem+=",";
            }
            if(mode.equals("PRO")) for(int i=0;i<procolorcount;i++) colorlistPicked[i]=0;
            else for(int i=0;i<basiccolorcount;i++) colorListPickedBasic[i]=0;
            etcolors.setText(tem);
        });

    }
}