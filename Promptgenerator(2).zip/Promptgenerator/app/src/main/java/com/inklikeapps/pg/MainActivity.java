package com.inklikeapps.pg;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    int colorcount = 1;
    Button copy, generate, colcount, switchmode;
    String mode = "BASIC";
    EditText etcolors, etprompt;
    String[] colorListWhite={"White","Snow White", "Ivory", "Cream", "Eggshell", "Champagne", "Vanilla", "Beige", "Bone White", "Linen", "Cotton White", "Chalk White", "Alabaster", "Bisque", "Ghost White", "Milk White", "Oyster White", "Seashell", "Antique White", "Egg White", "Whisper White", "Parchment", "Lily White", "Floral White", "Frost White", "Porcelain", "Creamy White", "Coconut White", "Magnolia", "Off-White", "Pearly White", "Dove White", "Navajo White", "Polar White", "Pure White", "Silk White", "Lily of the Valley", "Winter White", "Blanched Almond", "Seashell Pink", "Bleached Bone"};
    int[] colorListPickedWhite={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String[] colorListBlack={"Black","Onyx Black", "Jet Black", "Charcoal", "Ebony", "Coal Black", "Pitch Black", "Midnight Black", "Soot Black", "Raven Black", "Sable", "Licorice Black", "Obsidian", "Inky Black", "Graphite", "Smokey Black", "Shadow Black", "Velvet Black", "Matte Black", "Caviar Black", "Oil Black", "Carbon Black", "Slate Black", "Leather Black", "Metallic Black", "Glossy Black", "Ash Black", "Pearl Black", "Lustrous Black", "Coal Miner's Black", "Vantablack", "Piano Black", "Bistre", "Noir", "Void Black", "Umbral Black", "Charred Black", "Mournful Black", "Deep Black", "Ink Black", "Darkness Black"};
    int[] colorListPickedBlack={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String[] colorListRed={"Red","Ruby Red", "Crimson", "Cherry Red", "Brick Red", "Scarlet", "Burgundy", "Mahogany", "Maroon", "Wine Red", "Rust Red", "Tomato Red", "Fire Engine Red", "Rose Red", "Candy Apple Red", "Magenta", "Fuchsia", "Berry Red", "Vermilion", "Bittersweet", "Raspberry Red", "Blood Red", "Candy Red", "Cinnabar", "Coral Red", "Dark Red", "Indian Red", "Lava Red", "Raspberry Rose", "Rouge", "Sangria Red", "Terra Cotta", "Venetian Red", "Vivid Red", "Watermelon Red", "Flame Red", "Lust Red", "Salmon Red", "Rouge Red", "Tawny Red", "Imperial Red"};
    int[] colorListPickedRed={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String[] colorListBlue={"Blue","Navy Blue", "Royal Blue", "Sky Blue", "Cobalt Blue", "Baby Blue", "Azure Blue", "Cerulean Blue", "Turquoise Blue", "Teal", "Electric Blue", "Indigo", "Powder Blue", "Denim Blue", "Prussian Blue", "Steel Blue", "Ultramarine Blue", "Cornflower Blue", "Periwinkle Blue", "Ice Blue", "Midnight Blue", "Aegean Blue", "Baby Powder Blue", "Carolina Blue", "Electric Cyan", "Glaucous Blue", "Maya Blue", "Robin Egg Blue", "Sapphire Blue", "Steel Teal", "Tiffany Blue", "Egyptian Blue", "Han Blue", "Navy Teal", "Celestial Blue", "Ocean Blue", "Peacock Blue", "Slate Blue", "Teal Blue", "Tropical Blue", "Verdigris Blue"};
    int[] colorListPickedBlue={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String[] colorlistPro = {"Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown", "Black", "White", "Gray", "Beige", "Turquoise", "Indigo", "Lavender", "Cyan", "Maroon", "Olive", "Gold", "Silver", "Teal", "Coral", "Mauve", "Salmon", "Tan", "Charcoal", "Plum", "Ivory", "Sky Blue", "Navy Blue", "Forest Green", "Lemon Yellow", "Peach", "Ruby", "Slate Gray", "Periwinkle", "Chocolate Brown", "Midnight Blue", "Rose", "Mint Green", "Mustard Yellow", "Lilac", "Sand", "Brick Red", "Orchid", "Seafoam Green", "Amber", "Cream", "Pewter", "Aqua", "Mahogany", "Slate Blue", "Tangerine", "Olive Green", "Cyan Blue", "Eggshell", "Coral Pink", "Burgundy", "Sage Green", "Dusty Rose", "Steel Blue", "Apricot", "Bronze", "Mint", "Ruby Red", "Champagne", "Cinnamon", "Fern Green", "Lavender Blue", "Sienna", "Tomato Red", "Topaz", "Vermilion", "Wheat", "Orchid Purple", "Royal Blue", "Olive Drab", "Coral Orange", "Pewter Gray", "Rust", "Aquamarine", "Lime", "Lemon", "Jade", "Tiffany Blue", "Electric Blue", "Hot Pink", "Magenta", "Terra Cotta", "Burnt Sienna", "Peacock Blue", "Emerald Green", "Royal Purple", "Sunset Orange", "Midnight Black", "Snow White", "Saffron Yellow", "Crimson Red", "Lapis Lazuli Blue", "Copper", "Platinum", "Amethyst Purple", "Chartreuse", "Moss Green", "Violet", "Sepia", "Azure Blue", "Ochre", "Goldenrod", "Linen White"};
    int[] colorlistPicked={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    String[] colorListBasic ={"Black", "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown", "White", "Gray", "Indigo", "Cyan", "Maroon", "Golden", "Silver", "Teal" };
    int[] colorListPickedBasic={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int min = 0;
    final int procolorcount = 110,basiccolorcount=17,bluecolorcount=41,redcolorcount=41,whitecolorcount=41,blackcolorcount=41;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_main);

        copy=findViewById(R.id.bt_copy);
        switchmode=findViewById(R.id.bt_mode);
        etcolors=findViewById(R.id.et_colors);
        etprompt=findViewById(R.id.et_prompt);
        generate=findViewById(R.id.bt_generate);
        colcount=findViewById(R.id.bt_colcount);

        switchmode.setOnClickListener(view -> {
            switch(mode) {
                case "BASIC":
                    mode="PRO";
                    switchmode.setBackgroundResource(R.drawable.round_button_pro);
                    switchmode.setTextColor(getResources().getColor(R.color.white));
                    break;
                case "PRO":
                    mode="BLUES";
                    switchmode.setBackgroundResource(R.drawable.round_button_blue);
                    switchmode.setTextColor(getResources().getColor(R.color.white));
                    break;
                case "BLUES":
                    mode="REDS";
                    switchmode.setBackgroundResource(R.drawable.round_button_red);
                    switchmode.setTextColor(getResources().getColor(R.color.white));
                    break;
                case "REDS":
                    mode="WHITES";
                    switchmode.setBackgroundResource(R.drawable.round_button_white);
                    switchmode.setTextColor(getResources().getColor(R.color.black));
                    break;
                case "WHITES":
                    mode="BLACKS";
                    switchmode.setBackgroundResource(R.drawable.round_button_black);
                    switchmode.setTextColor(getResources().getColor(R.color.white));
                    break;
                case "BLACKS":
                    mode="BASIC";
                    switchmode.setBackgroundResource(R.drawable.round_button);
                    switchmode.setTextColor(getResources().getColor(R.color.white));
                    break;
            }
            switchmode.setText(mode);
        });
        copy.setOnClickListener(view -> {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

            // Create a new ClipData with the text
            String textToCopy=etcolors.getText().toString()+" "+etprompt.getText().toString();
            ClipData clipData = ClipData.newPlainText("", textToCopy);

            // Set the ClipData to the clipboard
            clipboardManager.setPrimaryClip(clipData);

            Toast.makeText(MainActivity.this, "Prompt copied to clipboard", Toast.LENGTH_SHORT).show();
        });
        colcount.setOnClickListener(view -> {
            colorcount++;
            if(colorcount>8) colorcount=1;
            colcount.setText(Integer.toString(colorcount));
        });

        generate.setOnClickListener(view -> {



            etcolors.setText("");
            String[] pickedcolors = new String[colorcount];
            for(int i=0;i<colorcount;i++) {

                switch (mode) {
                    case "PRO": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(procolorcount);
                        }
                        while (colorlistPicked[randomNumber] == 1);
                        colorlistPicked[randomNumber] = 1;
                        pickedcolors[i] = colorlistPro[randomNumber];
                        break;
                    }
                    case "BASIC": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(basiccolorcount);
                        }
                        while (colorListPickedBasic[randomNumber] == 1);
                        colorListPickedBasic[randomNumber] = 1;
                        pickedcolors[i] = colorListBasic[randomNumber];
                        break;
                    }
                    case "BLUES": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(bluecolorcount);
                        }
                        while (colorListPickedBlue[randomNumber] == 1);
                        colorListPickedBlue[randomNumber] = 1;
                        pickedcolors[i] = colorListBlue[randomNumber];
                        break;
                    }
                    case "REDS": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(redcolorcount);
                        }
                        while (colorListPickedRed[randomNumber] == 1);
                        colorListPickedRed[randomNumber] = 1;
                        pickedcolors[i] = colorListRed[randomNumber];
                        break;
                    }
                    case "WHITES": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(whitecolorcount);
                        }
                        while (colorListPickedWhite[randomNumber] == 1);
                        colorListPickedWhite[randomNumber] = 1;
                        pickedcolors[i] = colorListWhite[randomNumber];
                        break;
                    }
                    case "BLACKS": {
                        Random random = new Random();
                        int randomNumber;
                        do {
                            randomNumber = random.nextInt(blackcolorcount);
                        }
                        while (colorListPickedBlack[randomNumber] == 1);
                        colorListPickedRed[randomNumber] = 1;
                        pickedcolors[i] = colorListBlack[randomNumber];
                        break;
                    }
                }

            }
            String tem="";
            for(int i=0;i<colorcount;i++) {
                tem+=pickedcolors[i];
                if(i==colorcount-1) continue;
                tem+=",";
            }
            switch (mode) {
                case "PRO":
                    for (int i = 0; i < procolorcount; i++) colorlistPicked[i] = 0;
                    break;
                case "BASIC":
                    for (int i = 0; i < basiccolorcount; i++) colorListPickedBasic[i] = 0;
                    break;
                case "BLUES":
                    for (int i = 0; i < bluecolorcount; i++) colorListPickedBlue[i] = 0;
                    break;
                case "REDS":
                    for (int i = 0; i < redcolorcount; i++) colorListPickedRed[i] = 0;
                    break;
                case "WHITES":
                    for (int i = 0; i < whitecolorcount; i++) colorListPickedWhite[i] = 0;
                    break;
                case "BLACKS":
                    for (int i = 0; i < blackcolorcount; i++) colorListPickedBlack[i] = 0;
                    break;
            }
            etcolors.setText(tem);
        });

    }
}